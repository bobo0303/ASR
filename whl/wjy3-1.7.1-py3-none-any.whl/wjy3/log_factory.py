import logging, logging.config
import os

if not os.path.exists("logs/log.log"):
    os.makedirs(os.path.dirname("logs/log.log"), exist_ok=True)

logging.config.fileConfig("logging.conf")


def get_logger(logger_name: str = ""):
    """
    取得logger物件

    arg:
        logger_name: 對應到logging.conf中的logger name，預設不給值會回傳root logger
    """
    return logging.getLogger(logger_name)
