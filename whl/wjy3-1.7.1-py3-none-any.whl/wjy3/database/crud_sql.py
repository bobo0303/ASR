from sqlalchemy.orm import Session
from .session import get_db_session
from typing import Any, Generic, TypeVar, List, final
from datetime import datetime
from .abstract_table import AbstractTable
import pytz

T = TypeVar('T', bound=AbstractTable)


class CrudSql(Generic[T]):

    def __init__(self, table: T, db: Session = None):
        """
        args:
            table: table class
            db(option): db session
        """
        self.table = table
        self.db = db if db else next(get_db_session())

    @final
    def close_connect(self):
        """
        close db session
        """
        if self.db:
            self.db.close()

    @final
    def get_one(self, **filter) -> T:
        """
        get one data from database

        args:
            **filter: column filter

        return:
            data found
        """
        r = self.db.query(self.table)
        if filter:
            r = r.filter_by(**filter)
        r = r.limit(1).all()
        return None if not r else r[0]

    @final
    def get_by_uid(self, uid: int) -> T:
        """
        get one data by uid

        args:
            uid: uid value

        return:
            data found
        """
        r = self.get_one(uid=uid)
        return r

    @final
    def get_list(self, limit: int = None, *order_by, **filter) -> List[T]:
        """
        get list data from database

        args:
            limit: limit of data rows
            *order_by: order by
            **filter: column filter

        return:
            data list found
        """
        r = self.db.query(self.table)
        if filter:
            r = r.filter_by(**filter)
        if order_by:
            r = r.order_by(*order_by)
        if limit:
            r = r.limit(limit)
        r = r.all()
        return r

    @final
    def create(self, source: T) -> T:
        """
        create and commit one row data

        args:
            source: data source

        return:
            data after created
        """
        self.db.add(source)
        self.db.commit()
        self.db.refresh(source)
        return source

    @final
    def create_batch(self, sources: List[T], refresh: bool = True) -> List[T]:
        """
        create and commit rows data batch

        args:
            sources: batch create data sources
            refresh: refresh sources data

        return:
            data list after created
        """
        self.db.add_all(sources)
        self.db.commit()
        if refresh:
            for s in sources:
                self.db.refresh(s)
        return sources

    @final
    def merge_to_target(self, source: Any) -> T:

        # 判斷資料來源是否有uid欄位
        if not hasattr(source, "uid"):
            raise Exception("can't merge cause source has no attribute uid")

        uid = getattr(source, "uid")

        # 判斷資料來源uid欄位是否為空
        if not (uid and str(uid).strip()):
            raise Exception("can't merge cause source uid column is empty")

        target = self.get_by_uid(uid)

        if not target:
            raise Exception("can't merge cause can't find %s data by uid: %s" % (
                self.table.__class__.__tablename__, uid
            ))

        columns = source.schema().get("properties").keys()

        for c in columns:
            if c not in ("create_time", "lm_time", "create_date") and hasattr(target, c):
                setattr(target, c, getattr(source, c))

        return target

    @final
    def update(self, source: T) -> T:
        """
        update and commit one row data

        args:
            source: data source

        return:
            data after updated
        """
        timezone = pytz.timezone('Asia/Taipei')
        source.lm_time = datetime.now(timezone)
        self.db.commit()
        self.db.refresh(source)
        return source

    @final
    def delete(self, source: T):
        """
        delete and commit one row data

        args:
            source: data source
        """
        self.db.delete(source)
        self.db.commit()

    @final
    def delete_by_uid(self, uid: int):
        """
        delete and commit data by uid

        args:
            uid: uid value
        """
        self.db.delete(self.get_by_uid(uid))
        self.db.commit()
