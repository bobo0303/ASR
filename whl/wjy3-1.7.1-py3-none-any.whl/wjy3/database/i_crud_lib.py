from typing import Any, Generic, List, TypeVar

T = TypeVar('T')

class ICrudLib(Generic[T]):

    def create(self, source: Any, **kwargs) -> T:
        pass

    def create_batch(self, source: Any, **kwargs) -> List[T]:
        pass

    def update(self, source: Any, **kwargs) -> T:
        pass

    def delete(self, **kwargs):
        pass