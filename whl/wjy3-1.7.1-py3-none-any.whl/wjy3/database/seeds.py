from abc import ABCMeta, abstractmethod

class DatabaseSeeder(metaclass=ABCMeta):

    def run_task(self):
        if self.is_patch():
            self.task()

    def is_patch(self) -> bool:
        return True

    @abstractmethod
    def task(self):
        return NotImplemented
    

def add_seeds():

    def wrap(cls):
        from .session import seeds_cls
        # 檢查是否繼承Seed
        assert(issubclass(cls, DatabaseSeeder))
        seeds_cls.append(cls)
        return cls
    
    return wrap