import uuid
import random
from .session import Base
from sqlalchemy import *
from datetime import datetime, date
from wjy3.yml_utils import YmlUtils
from sqlalchemy.ext.declarative import declared_attr
import pytz

config = YmlUtils("app.yml")
active = config.get_val("database.active")
prefix = config.get_val(f"database.application.{active}.prefix")


class AbstractTable(Base):

    __abstract__ = True

    @declared_attr
    def __tablename__(cls):
        assert prefix, "Table prefix can not be null, setup in app.yml"
        assert hasattr(
            cls, '_table_name'), f"_table_name must be set in the subclass, cls name: {cls}"
        return f"{prefix}_{cls._table_name}"

    # uuid
    uid = Column(String(length=32), primary_key=True, index=True)

    # 建立時間
    create_time = Column(DateTime, nullable=False)

    # 最後更新時間
    lm_time = Column(DateTime, nullable=False)

    # 最後更新使用者
    lm_user = Column(String(length=50), nullable=False)

    # 建立日期 (未來資料上databricks做partitions)
    create_date = Column(Date, nullable=False)

    def __init__(self, lm_user="system") -> None:
        timezone = pytz.timezone('Asia/Taipei')
        current_date = datetime.now(timezone)
        self.uid = self.__gen_uuid()
        self.lm_user = lm_user
        self.create_time = current_date
        self.lm_time = current_date
        self.create_date = current_date.date()

    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        columns = self.__table__.columns.keys()
        str_tmp = []
        for c in columns:
            str_tmp.append(f"{c}='{getattr(self, c)}'")
        return "<%s(%s)>" % (class_name, ", ".join(str_tmp))

    def get_create_time_strf(self) -> str:
        return "" if not self.create_time else self.create_time.strftime("%Y/%m/%d %H:%M:%S")

    def get_lm_time_strf(self) -> str:
        return "" if not self.lm_time else self.lm_time.strftime("%Y/%m/%d %H:%M:%S")

    def __gen_uuid(self):
        return str(uuid.uuid3(uuid.NAMESPACE_DNS, str(datetime.now().timestamp()) + str(random.random()))).replace("-", "")
