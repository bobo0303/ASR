from ruamel.yaml import YAML
from .log_factory import get_logger
from typing import Any

class YmlUtils():
    """
    yml解析工具

    author: weston
    """

    def __init__(self, yml_file: str):
        self.log = get_logger()
        self.yaml = YAML()
        self.yml_file = yml_file
        with open(yml_file, encoding="utf-8") as stream:
            self.config = self.yaml.load(stream)

    def get_val(self, key: str) -> Any:
        """
        取得yaml相對應value

        args:
            key: key值, 利用"."取得下層物件, "[0-9]"取得list物件

        ex:
            database[0].host -> database下第0個物件中host的對應值
        """
        try:
            key.replace("[", ".").replace("]", "")
            kl = key.split(".")
            r = self.config
            for k in kl:
                r = r[k]
        except Exception as e:
            self.log.error(repr(e))
            raise e
        return r

    def set_val(self, key: str, val: Any):
        """
        更新yaml value

        args:
            key: key值, 利用"."取得下層物件, "[0-9]"取得list物件
            val: 要修改的值

        ex:
            database[0].host -> database下第0個物件中host的對應值
        """
        try:
            key.replace("[", ".").replace("]", "")
            kl = key.split(".")
            tmp = self.config
            l = len(kl)
            t = 0
            for k in kl:
                t += 1
                if t == l:
                    tmp[k] = val
                else:
                    tmp = tmp[k]

            with open(self.yml_file, "w", encoding="utf-8") as stream:
                self.yaml.dump(self.config, stream)
        except Exception as e:
            self.log.error(repr(e))
            raise e