import threading
from unittest.mock import patch
from starlette.requests import Request
from starlette.responses import Response
from starlette.middleware.base import BaseHTTPMiddleware
from .overrider import override

class UrlMiddleware(BaseHTTPMiddleware):
    """
    針對指定url所使用的middleware，監聽該url的觸發事件

    使用方法:
        繼承此類後實作action()，需搭配@url_middleware使用

    author: weston
    """

    # 監聽url path
    _path: str

    # 監聽url path的method, e.g.: get, post, put, delete
    _method: str

    # 使用同步
    _async: bool

    @override(BaseHTTPMiddleware)
    async def dispatch(self, request: Request, call_next):

        # 檢查是否使用@url_middleware指定url及method
        if not (self._path and self._method):
            raise Exception(f"class {self.__class__.__name__} doesn't use @url_middleware assign url and method")

        # 檢查method及url path是否吻合
        if self.__check_method(request.method) and self.__check_url(request.url.path):
            request_body = await request.json()

            # 使用with patch.object避免因重複使用request物件而爆炸
            with patch.object(Request, "body", request.body):
                response = await call_next(request)

            # 判斷是否使用非同步
            if self._async:

                # 使用多執行緒實作同步
                t = threading.Thread(target=self.action,
                    args=[
                        request,
                        response,
                        request.path_params,
                        dict(request.query_params),
                        request_body
                    ]
                )
                t.start()
            else:
                self.action(request, response, request.path_params, dict(request.query_params), request_body)
        
        else:
            response = await call_next(request)

        return response

    def __check_method(self, request_method: str) -> bool:
        """
        檢查request_method與self._method是否吻合
        """
        if request_method.strip() == "*":
            return True

        if self._method == request_method:
            return True

        return False

    def __check_url(self, request_url: str) -> bool:
        """
        檢查request_url與self._path是否吻合
        """
        if request_url.strip() == "*":
            return True

        request_url_tmp = request_url.split("/")
        listen_url_tmp = self._path.split("/")

        if len(request_url_tmp) < len(listen_url_tmp):
            return False

        for i in range(len(listen_url_tmp)):
            v = listen_url_tmp[i]
            if v == "*":
                return True
            elif not v == request_url_tmp[i]:
                return False
        
        return True


    def action(
        self,
        request: Request,
        response: Response,
        path_param: dict,
        query_param: dict,
        request_body: dict
    ) -> Response:
        return NotImplemented

def url_middleware(url: str, method: str, is_async: bool = False):
    """
    指定監聽的url及method

    args:
        url: url
        method: url method, e.g.: get, post, put, delete
        is_async: use async, default False

    author: weston
    """
    assert(url != "")
    assert(method != "")

    def wrap(cls):
        # 檢查是否繼承UrlMiddleware
        assert(issubclass(cls, UrlMiddleware))
        cls._path = url
        cls._method = method.upper()
        cls._async = is_async
        return cls
    
    return wrap